#include <iostream>
using namespace std;
int main(){
    int arr[][4] = {{5,8,1,2},{4,9,5,7},{1,2,3,4}};
    int mx = arr[0][0];
        for(int i=0;i<3;i++){
            for(int j=0;j<4;j++){
                if(mx<arr[i][j]){
                mx=arr[i][j];
                }


        }
    }
    cout<<mx;
}